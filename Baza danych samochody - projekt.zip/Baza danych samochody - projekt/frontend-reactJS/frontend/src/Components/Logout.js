import React, { Component } from 'react'

class Logout extends Component {
    render() {
        return (
            <>
                <h1>Wylogowano</h1>
                <div className="container">
                    Dziękujemy
                </div>
            </>
        )
    }
}

export default Logout;